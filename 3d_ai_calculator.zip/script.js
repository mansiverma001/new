const display = document.getElementById('display');
const historyList = document.getElementById('historyList');
const memoryDisplay = document.getElementById('memoryValue');
let memory = 0;

function appendValue(value) {
  if (display.innerText === '0') display.innerText = value;
  else display.innerText += value;
}

function clearDisplay() {
  display.innerText = '0';
}

function deleteLast() {
  display.innerText = display.innerText.length > 1 ? display.innerText.slice(0, -1) : '0';
}

function toggleSign() {
  if (display.innerText.startsWith('-')) display.innerText = display.innerText.slice(1);
  else if (display.innerText !== '0') display.innerText = '-' + display.innerText;
}

function calculateResult() {
  try {
    let result = eval(display.innerText);
    let record = display.innerText + " = " + result;
    display.innerText = result;
    addToHistory(record);
  } catch {
    display.innerText = 'Error';
  }
}

function addToHistory(entry) {
  const p = document.createElement('p');
  p.innerText = entry;
  historyList.prepend(p);
}

function startVoice() {
  if (!('webkitSpeechRecognition' in window)) {
    alert("Speech Recognition not supported");
    return;
  }
  const rec = new webkitSpeechRecognition();
  rec.lang = 'en-US';
  rec.onresult = (e) => {
    const speech = e.results[0][0].transcript;
    display.innerText = speech.replace(/plus/gi, '+')
                              .replace(/minus/gi, '-')
                              .replace(/times/gi, '*')
                              .replace(/divide/gi, '/');
  };
  rec.start();
}

function plotGraph() {
  try {
    const expr = display.innerText;
    const labels = [];
    const data = [];
    for (let x = -10; x <= 10; x++) {
      const y = eval(expr.replace(/x/g, x));
      labels.push(x);
      data.push(y);
    }
    new Chart(document.getElementById("graphCanvas"), {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'y = ' + expr,
          data: data,
          borderColor: 'lime',
          fill: false
        }]
      }
    });
  } catch {
    alert("Invalid function (use x as variable)");
  }
}

function webSearch() {
  const query = display.innerText;
  window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, "_blank");
}

function memoryAdd() {
  memory = eval(display.innerText);
  memoryDisplay.innerText = "Stored: " + memory;
}

function memoryRecall() {
  display.innerText = memory.toString();
}

function memoryClear() {
  memory = 0;
  memoryDisplay.innerText = "Stored: 0";
}